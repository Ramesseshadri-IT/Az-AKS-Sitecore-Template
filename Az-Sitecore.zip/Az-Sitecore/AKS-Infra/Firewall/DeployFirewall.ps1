param (
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $Location = 'westeurope',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $FWResourceGroupName = 'ReadFromVariable_Infra-<Env>_ResourceGroup',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $VNETName = 'ReadFromVariable_Infra-<Env>_VirtualNetworkName',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AKSSubnetName = 'AksSubnet',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $FWName = 'ReadFromVariable_Infra-<Env>_FirewallName',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $FWPIP = 'ReadFromVariable_Infra-<Env>_FirewallIP',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $FWIPConfigName = 'aks-egress-fwconfig',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $RouteTable = 'ReadFromVariable_Infra-<Env>_RouteTable',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $Route = 'aks-egress-fwrn',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $RouteINT = 'aks-egress-fwinternet'

)

# 1) Create Azure Public IP to Route the Azure firewall traffic for public facing segment to protect AKS Environment

Write-Host "--- Create Azure Public IP to Route the Azure firewall traffic for public facing segment to protect AKS Environment---" -ForegroundColor Cyan

az network public-ip create `
--name $FWPIP `
--resource-group $FWResourceGroupName `
--location $Location `
--allocation-method static `
--sku standard `
--zone 1

Write-Host "--- Complete: Created Public IP for firewall to protect Egress traffic on AKS Env ---" -ForegroundColor Green


# 2) Create Azure Firewall on Existing VNET based for Egress traffic filter to protect AKS Environment

# Install Azure Firewall preview CLI extension

az extension add --name azure-firewall

Write-Host "--- Deploy firewall on Existing VNET based for Egress traffic filter to protect AKS Environment---" -ForegroundColor Cyan

az network firewall create `
--name $FWName `
--resource-group $FWResourceGroupName `
--location $Location `
--enable-dns-proxy true `
--tier Standard `
--zones 1 `
--tags Team=Sitecore Environment=ProductionEnv Name=CorpWebsiteDEV

Write-Host "--- Complete: Deployed firewall to protect Egress traffic on AKS Env ---" -ForegroundColor Green

# 3) Create Azure Firewall IP configuration & rule update to protect AKS Environment

Write-Host "--- Create Azure Firewall IP configuration & rule update to protect AKS Environment---" -ForegroundColor Cyan

# 3.a) Configure Firewall IP Config


az network firewall ip-config create `
--firewall-name $FWName `
--name $FWIPConfigName  `
--public-ip-address $FWPIP `
--resource-group $FWResourceGroupName `
--vnet-name $VNETName 

# 3.b) Capture Firewall IP Address for Later Use

Write-Host "--- Capture Firewall IP Address for Later Use to protect AKS Environment---" -ForegroundColor Cyan

$FWPUBLIC_IP=$(az network public-ip show -g $FWResourceGroupName -n $FWPIP --query "ipAddress" -o tsv)
Write-Output $FWPUBLIC_IP

$FWPRIVATE_IP=$(az network firewall show -g $FWResourceGroupName -n $FWName --query "ipConfigurations[0].privateIpAddress" -o tsv)
Write-Output $FWPRIVATE_IP

Write-Host "--- Complete: Capture Firewall IP Address for Later Use to protect AKS Environment ---" -ForegroundColor Green

# 3.c) Create Azure Firewall Default Rooute configuration to protect AKS Environment


Write-Host "--- Create a table, with BGP Route propagation disabled---" -ForegroundColor Cyan


az network Route-table create `
    --name $RouteTable `
    --resource-group $FWResourceGroupName `
    --location $Location `
    --disable-bgp-route-propagation true

Write-Host "--- Complete: Created a table, with BGP Route propagation disabled  ---" -ForegroundColor Green

Write-Host "--- Route creation---" -ForegroundColor Cyan

az network Route-table Route create `
  --resource-group $FWResourceGroupName `
  --name $Route `
  --route-table-name $RouteTable `
  --address-prefix 0.0.0.0/0 `
  --next-hop-type VirtualAppliance `
  --next-hop-ip-address $FWPRIVATE_IP

az network Route-table Route create `
    --name $RouteINT `
    --route-table-name $RouteTable `
    --address-prefix $FWPUBLIC_IP/32 `
    --resource-group $FWResourceGroupName `
    --next-hop-type Internet
 
Write-Host "---Complete:  Route created ---" -ForegroundColor Green

# 4) Create and update the FW Network and Application Egress traffic Rules

#4.a) Create FW Network and Application Egress traffic Rules

Write-Host "--- Create Firewall Rule for Egress traffic " -ForegroundColor Cyan

az network firewall network-rule create `
-g $FWResourceGroupName `
-f $FWName `
--collection-name 'aksfwnr' `
-n 'apiudp' `
--protocols 'UDP' `
--source-addresses '*' `
--destination-addresses "AzureCloud.$Location" `
--destination-ports 1194 --action allow --priority 100


az network firewall network-rule create `
-g $FWResourceGroupName `
-f $FWName `
--collection-name 'aksfwnr' `
-n 'apitcp' `
--protocols 'TCP' `
--source-addresses '*' `
--destination-addresses "AzureCloud.$Location" `
--destination-ports 9000


az network firewall network-rule create `
-g $FWResourceGroupName `
-f $FWName `
--collection-name 'aksfwnr' `
-n 'time' `
--protocols 'UDP' `
--source-addresses '*' `
--destination-fqdns 'ntp.ubuntu.com' `
--destination-ports 123

az network firewall network-rule create `
--firewall-name $FWNAME `
--collection-name "servicetags" `
--destination-addresses "AzureContainerRegistry" `
                        "MicrosoftContainerRegistry" `
                        "AzureActiveDirectory" `
                        "AzureMonitor" `
--destination-ports "*" `
--name "allow service tags" `
--protocols "Any" `
--resource-group $FWResourceGroupName `
--source-addresses "*" `
--action "Allow" `
--description "allow service tags" `
--priority 110

#4.b ) Add FW Application Rules

az network firewall application-rule create `
-g $FWResourceGroupName `
-f $FWName `
--collection-name 'aksfwar' `
-n 'fqdn' `
--source-addresses '*' `
--protocols 'http=80' 'https=443' `
--fqdn-tags "AzureKubernetesService" `
--action allow --priority 100

az network firewall application-rule create `
--firewall-name $FWNAME  `
--collection-name "osupdates"  `
--name "allow network"  `
--protocols http=80 https=443  `
--source-addresses "*"  `
--resource-group $FWResourceGroupName  `
--action "Allow"  `
--target-fqdns  `
    "download.opensuse.org" `
    "security.ubuntu.com"  `
    "packages.microsoft.com"  `
    "azure.archive.ubuntu.com"  `
    "changelogs.ubuntu.com"  `
    "snapcraft.io"  `
    "api.snapcraft.io"  `
    "motd.ubuntu.com" `
--priority 110


az network firewall application-rule create  `
--firewall-name $FWNAME  `
--collection-name "dockerhub"  `
--name "allow network"  `
--protocols http=80 https=443  `
--source-addresses "*"  `
--resource-group $FWResourceGroupName  `
--action "Allow"  `
--target-fqdns "*auth.docker.io"  `
               "*cloudflare.docker.io"  `
               "*cloudflare.docker.com"  `
               "*registry-1.docker.io" `
--priority 130

az network firewall application-rule create `
--firewall-name $FWNAME  `
--collection-name "Carbon-black"  `
--name "allow network"  `
--protocols https=443  `
--source-addresses "*"  `
--resource-group $FWResourceGroupName  `
--action "Allow"  `
--target-fqdns  `
    "defense-eap01.conferdeploy.net" `
    "events.containers.carbonblack.io" `
    "dashboard.confer.net" `
    "defense.conferdeploy.net" `
    "defense-prod05.conferdeploy.net" `
    "events-eu.containers.carbonblack.io" `
    "defense-prodnrt.conferdeploy.net" `
    "events-prodnrt.containers.carbonblack.io" `
    "defense-prodsyd.conferdeploy.net" `
    "events-prodsyd.containers.carbonblack.io" `
--priority 140


Write-Host "--- Complete : Firewall Rule updated for Egress traffic " -ForegroundColor Green

# 5) Associate Route table with next hop to Firewall to the AKS subnet

Write-Host "--- Associate Route table with next hop to Firewall to the AKS subnet Egress traffic " -ForegroundColor Cyan

az network vnet subnet update `
-g $FWResourceGroupName `
--vnet-name $VNETName `
--name $AKSSubnetName `
--route-table $RouteTable

Write-Host "---Complete : Associated Route table with next hop to Firewall to the AKS subnet Egress traffic" -ForegroundColor Green