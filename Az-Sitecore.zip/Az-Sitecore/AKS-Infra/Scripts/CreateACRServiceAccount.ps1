param (
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $ACRName = 'CEAUES022RG02ACR01',
    
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $ServicePrincipalName = 'CEAUES022RG02ACR01-Service-Principal'

 
)

# Obtain the full registry ID for subsequent command args
$ACR_REGISTRY_ID=$(az acr show --name $ACRName --query id --output tsv)

# Create the service principal with rights scoped to the registry.
# Default permissions are for docker pull access. Modify the '--role'
# argument value as desired:
# acrpull:     pull only
# acrpush:     push and pull
# owner:       push, pull, and assign roles
$SP_PASSWD=$(az ad sp create-for-rbac --name $ServicePrincipalName --scopes $ACR_REGISTRY_ID --role acrpull --query password --output tsv)
$SP_APP_ID=$(az ad sp list --display-name $ServicePrincipalName --query [].appId --output tsv)

# Output the service principal's credentials; use these in your services and
# applications to authenticate to the container registry.
Write-Host "Service principal ID: $SP_APP_ID"
Write-Host "Service principal password: $SP_PASSWD"


Write-Host "--- Complete: ACR Service Account Created ---" -ForegroundColor Green