param (
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AKSName = 'ReadFromVariable_Env_AKSName',
    
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $ResourceGroupName = 'ReadFromVariable_Env_ResourceGroup',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $keyVault = 'ReadFromVariable_Env_KeyVaultName',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $KeyvaultManagedidentity = 'ReadFromVariable_Env_KeyvaultManagedidentity',

    #please create the following variable in Devops#

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AppGatewayName = 'ReadFromVariable_Env_ppGatewayName',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AppGatewayManagedIdentity = 'ReadFromVariable_Env_AppGatewayManagedIdentity',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AKSManagedidentity = 'ReadFromVariable_Env_AKSManagedidentity'

    

)

#Create RBAC Managed identities for AppGw access the Environment

Write-Host "--- Create Managed Identity for AppGw to AKS Env---" -ForegroundColor Cyan

#az identity create -n $AppGatewayManagedIdentity -g $ResourceGroupName -l westeurope --query principalId -o tsv

az identity create `
  --resource-group $ResourceGroupName `
  --name $AppGatewayManagedIdentity

Write-Host "--- Complete: AppGw identity for AKS Env ---" -ForegroundColor Green

# Get service Resource ID of the user-assigned identity

Write-Host "--- Generate service Resource ID & assign Network gateway Managed Identity for AppGw to AKS Env---" -ForegroundColor Cyan

$appgwID=$(az identity show `
--resource-group $ResourceGroupName `
--name $AppGatewayManagedIdentity --query id --output tsv)

az network application-gateway identity assign `
            -g $ResourceGroupName `
            --gateway-name $AppGatewayName `
            --identity $appgwID

Write-Host "--- Generate service Resource ID & assign Network gateway Managed Identity for AppGw to AKS Env---" -ForegroundColor Green


# Get service principal ID of the user-assigned identity

$appgwID=$(az identity show `
--resource-group $ResourceGroupName `
--name $AppGatewayManagedIdentity --query principalId --output tsv)

$AKSID=$(az identity show `
--resource-group $ResourceGroupName `
--name $AKSManagedidentity --query principalId --output tsv)


#Assign specific roles to the AKS cluster you've created.

# clientId is to be retrive from the Kubernetes az aks show --name CEAUESITEAKS1 --resource-group AKS-Infra
#Documentation for all required role assignments with Azure Active Directory (Azure AD) pod identit


#$clientId=$(az aks show -g $ResourceGroupName -n $AKSName --query identityProfile.kubeletidentity.clientId -otsv)
$objectId=$(az aks show -g $ResourceGroupName -n $AKSName --query identityProfile.kubeletidentity.objectId -otsv)
$AKsdefaultResourceGroupName = "MC_"+$ResourceGroupName+"_"+$AKSName+"_westeurope"


az role assignment create `
--assignee-principal-type "ServicePrincipal" `
--role "Managed Identity Operator" `
--assignee-object-id $objectId --resource-group $ResourceGroupName

az role assignment create `
--assignee-principal-type "ServicePrincipal" `
--role "Managed Identity Operator" `
--assignee-object-id $objectId --resource-group $AKsdefaultResourceGroupName

az role assignment create `
--assignee-principal-type "ServicePrincipal" `
--role "Virtual Machine Contributor" `
--assignee-object-id $objectId --resource-group $AKsdefaultResourceGroupName

#Grant the identity permissions to get secrets from your key vault. Use the AKS & AppGw ID from the User-assigned managed identity

Write-Host "--- AKS Access policies granting---" -ForegroundColor Cyan

az keyvault set-policy `
        -n $keyVault `
        --secret-permissions backup delete get list purge recover restore set `
        --object-id $AKSID
az keyvault set-policy `
        -n $keyVault `
        --key-permissions backup create decrypt delete encrypt get import list purge recover restore sign unwrapKey update verify wrapKey `
        --object-id $AKSID
az keyvault set-policy `
        -n $keyVault `
        --certificate-permissions backup create delete deleteissuers get getissuers import list listissuers managecontacts manageissuers purge recover restore setissuers update `
        --object-id $AKSID

Write-Host "--- AppGw Access policies granting---" -ForegroundColor Cyan

az keyvault set-policy `
        -n $keyVault `
        --secret-permissions backup delete get list purge recover restore set `
        --object-id $appgwID
az keyvault set-policy `
        -n $keyVault `
        --key-permissions backup create decrypt delete encrypt get import list purge recover restore sign unwrapKey update verify wrapKey `
        --object-id $appgwID
az keyvault set-policy `
        -n $keyVault `
        --certificate-permissions backup create delete deleteissuers get getissuers import list listissuers managecontacts manageissuers purge recover restore setissuers update `
        --object-id $appgwID

Write-Host "--- Access policies granted for AppGw & Aks ---" -ForegroundColor Green