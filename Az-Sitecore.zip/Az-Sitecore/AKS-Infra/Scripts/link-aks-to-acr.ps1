param (
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AKSResourceGroupName = 'CEAUES020A001RG01',
  
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AKSName = 'CEAUES020A001KS01',
    
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AKSSubscriptionID = 'f6968826-aec8-49b5-82df-a8f155152cd2',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $ACRResourceGroupName = 'ceaues022a001rg02',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $ACRName = 'ceaues022rg02acr01',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $ACRSubscriptionID = '629ff003-13f8-4893-9b8a-88b1d14e9020'
)

#az account set --subscription $AKSSubscriptionID

# link AKS to ACR
Write-Host "--- Linking AKS to ACR ---" -ForegroundColor Cyan
$ACRResourceID = "/subscriptions/$ACRSubscriptionID/resourceGroups/$ACRResourceGroupName/providers/Microsoft.ContainerRegistry/registries/$ACRName"
#$clientID = $(az aks show --resource-group $AKSResourceGroupName --name $AksName --query "servicePrincipalProfile.clientId" --output tsv)
#$acrId = $(az acr show --name $AcrName --resource-group $ACRResourceGroupName --query "id" --output tsv)
#az role assignment create --assignee $clientID --role acrpull --scope $acrId
Write-Host $ACRResourceID 
az aks update -n $AKSName -g $AKSResourceGroupName --attach-acr $ACRResourceID

#az identity create --resource-group $ACRResourceGroupName --name $ACRName

# Get service principal ID of the user-assigned identity
#$spID=$(az identity show --resource-group $ACRResourceGroupName --name $ACRName --query principalId --output tsv)
#$resourceID=$(az acr show --resource-group $ACRResourceGroupName --name $ACRName --query id --output tsv)
#az role assignment create --assignee $spID --scope $resourceID --role acrpush


Write-Host "--- Complete: AKS & ACR Linked ---" -ForegroundColor Green