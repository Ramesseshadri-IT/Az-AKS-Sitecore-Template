param (
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $Region = 'westeurope',
    
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $ResourceGroupName = 'CEAUES021A001RG01',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AppGWManagedidentity = 'CEAUESITEAPPGWIDENTITY',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $Certname = 'CEAUESITECORECERTSTORE',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $keyVault = 'CEAUESITEKEYS',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $ApwName = 'CEAUESITEAPPGW',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $SSL = 'CEAUESITECORESSL'

)

#Create ertificate Store in existing keyvault

# Use Azure CLI to install certificate to Application Gateway

write-host "Configure from a reference to a Key Vault unversioned secret id" -ForegroundColor Cyan

$versionedSecretId=$(az keyvault certificate show -n $Certname --vault-name $keyVault --query "sid" -o tsv)
$unversionedSecretId=$(echo $versionedSecretId | cut -d'/' -f-5) # remove the version from the url
az network application-gateway ssl-cert create -n $SSL --gateway-name $appgwName `
            --resource-group $ResourceGroupName --key-vault-secret-id $unversionedSecretId


#Verify SSL certificate

#For Key Vault
    az keyvault certificate list --vault-name $keyVault
#For APPGW
   az network application-gateway ssl-cert list -g $ResourceGroupName --gateway-name $appgwName
