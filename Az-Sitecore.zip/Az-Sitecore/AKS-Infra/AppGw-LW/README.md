This ARM template can be used to integrate the features of below services to create an UDR based Azure Kubernetes Cluster (AKS) cluster for Site core Environment . 
The template allows to deploy a rich set of AKS features such as:

1) Azure Monitor for containers add-on
2) Application Gateway & WAFv2 SKU
3) Virtual Network and Subnet information


