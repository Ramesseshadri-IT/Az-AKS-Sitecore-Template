﻿az login
az acr login -n CEAUES022RG02ACR01 --expose-token 
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-cd:10.1.1-ltsc2019  -t sitecorebaseimages/sitecore-xp1-cd:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-cd:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-cm:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-cm:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-cm:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-id:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-id:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-id:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-cortexprocessing:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-cortexprocessing:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-cortexprocessing:10.1.1.005862.846-10.0.17763.1999-ltsc2019

az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-cortexprocessingworker:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-cortexprocessingworker:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-cortexprocessingworker:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-cortexreporting:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-cortexreporting:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-cortexreporting:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-prc:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-prc:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-prc:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-xdbautomation:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbautomation:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbautomation:10.1.1.005862.846-10.0.17763.1999-ltsc2019

az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-xdbautomationrpt:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbautomationrpt:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbautomationrpt:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-xdbautomationworker:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbautomationworker:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbautomationworker:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-xdbcollection:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbcollection:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbcollection:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-xdbrefdata:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbrefdata:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbrefdata:10.1.1.005862.846-10.0.17763.1999-ltsc2019

az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-xdbsearch:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbsearch:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbsearch:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-xdbsearchworker:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbsearchworker:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-xdbsearchworker:10.1.1.005862.846-10.0.17763.1999-ltsc2019
 

#External Data for SIT
#-----------------------------------------------------------------------------------------------------------------------------------------------------
#Sitecore Example Uses this one for SQL
az acr import --name CEAUES022RG02ACR01 --source mcr.microsoft.com/mssql/server:2017-CU21-ubuntu-16.04 -t sitecorebaseimages/external/mssql/server:2017-CU21-ubuntu-16.04
#In this list this one is tagged for development and testing - https://raw.githubusercontent.com/Sitecore/docker-images/master/tags/sitecore-tags.md
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/nonproduction/mssql-developer:2017-10.1.1-ltsc2019 -t sitecorebaseimages/external/mssql-developer:2017-10.1.1-ltsc2019 -t sitecorebaseimages/mssql-developer:2017-10.1.1.005862.846-10.0.17763.1999-ltsc2019
#Also this one is listed and is not marked as non-Production
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-mssql:10.1.1-ltsc2019 -t sitecorebaseimages/sitecore-xp1-mssql:10.1.1-ltsc2019 -t sitecorebaseimages/external/sitecore-xp1-mssql:10.1.1.005862.846-10.0.17763.1999-ltsc2019


#Solr
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/nonproduction/solr:8.4.0-10.1.1-ltsc2019 -t sitecorebaseimages/external/solr:8.4.0-10.1.1-ltsc2019 -t sitecorebaseimages/external/solr:8.4.0-10.1.1.005862.846-10.0.17763.1999-ltsc2019
#Solr: Used by Sitecore template
az acr import --name CEAUES022RG02ACR01 --source docker.io/library/solr:8.4.0 -t sitecorebaseimageses/external/solr:8.4.0
#Redis: Used by Sitecore template
az acr import --name CEAUES022RG02ACR01 --source docker.io/library/redis:4.0.14-alpine -t sitecorebaseimageses/external/redis:4.0.14-alpine
#az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/nonproduction/redis:4.0.14-alpine -t redis:4.0.14-alpine
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-redis:10.1.1-ltsc2019 -t sitecorebaseimages/external/sitecore-redis:10.1.1-ltsc2019 -t sitecorebaseimages/external/sitecore-redis:10.1.1.005862.846-10.0.17763.1999-ltsc2019

#Init Jobs
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-mssql-init:10.1.1-ltsc2019 -t sitecorebaseimages/external/sitecore-xp1-mssql-init:10.1.1-ltsc2019 -t sitecorebaseimages/external/sitecore-xp1-mssql-init:10.1.1.005862.846-10.0.17763.1999-ltsc2019
az acr import --name CEAUES022RG02ACR01 --source scr.sitecore.com/sxp/sitecore-xp1-solr-init:10.1.1-ltsc2019 -t sitecorebaseimages/external/sitecore-xp1-solr-init:10.1.1-ltsc2019 -t sitecorebaseimages/external/sitecore-xp1-solr-init:10.1.1.005862.846-10.0.17763.1999-ltsc2019




