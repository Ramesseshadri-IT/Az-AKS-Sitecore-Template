param (
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $Location = 'westeurope',
    
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AKSResourceGroupName = 'AKS-Infra',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $FWResourceGroupName = 'AKS-Infra',
    
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AKSName = 'CEAUESITEAKS1',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $FWPIP = 'CEAUE-SITECORE-FW-PIP1',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $AKsdefaultResourceGroupName = 'MC_AKS-Infra_CEAUESITEAKS1_westeurope',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $KeyvaultManagedidentity = 'CEAUESITEKEYIDENITY'

)

# Get service principal ID of the user-assigned identity

$spID=$(az identity show --resource-group $AKsResourceGroupName --name $KeyvaultManagedidentity --query principalId --output tsv)

#Update Keyvault RBAC of Resource Group to access the Environment

Write-Host "--- Update RBAC Keyvault identities account to resource group for AKS Env---" -ForegroundColor Cyan

    az role assignment create --assignee $spID `
    --role "Reader" `
    --resource-group $AKsResourceGroupName

Write-Host "--- Complete: RBAC Keyvault identities account to resource group for AKS Env ---" -ForegroundColor Green

#Update RBAC of Default Resource Group of AKS to access the Environment

Write-Host "--- Update RBAC Keyvault identities account to default resource group for AKS Env---" -ForegroundColor Cyan
az role assignment create --assignee $spID `
--role "Reader" `
--resource-group $AKsdefaultResourceGroupName

Write-Host "--- Complete: RBAC Keyvault identities account to default resource group for AKS Env ---" -ForegroundColor Green

# Enable developer access to the API server & Retrieve your IP address

Write-Host "--- Generate Authorized Open DNS range to AKS Env---" -ForegroundColor Cyan

#$CURRENT_IP=$(dig resolver1.opendns.com ANY myip.opendns.com +short)

# Add to AKS approved list
$FWPUBLIC_IP=$(az network public-ip show -g $FWResourceGroupName -n $FWPIP --query "ipAddress" -o tsv)
Write-Output $FWPUBLIC_IP
az aks update -g $AksResourceGroupName -n $AKSNAME --api-server-authorized-ip-ranges $FWPUBLIC_IP,83.86.144.46/32,165.225.241.49/32

Write-Host "--- Complete: Authorization to Open DNS range updated to AKS Env- ---" -ForegroundColor Green

# authenticate AKS instance
Write-Host "--- Get credentials for k8s cluster ---" -ForegroundColor Cyan

az aks get-credentials --resource-group $AKsResourceGroupName --name $AksName --overwrite-existing

Write-Host "--- Complete: Credentials for k8s cluster retrieved ---" -ForegroundColor Green